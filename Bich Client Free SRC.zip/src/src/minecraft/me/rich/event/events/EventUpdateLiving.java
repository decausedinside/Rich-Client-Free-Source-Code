package me.rich.event.events;

import me.rich.event.Event;

public class EventUpdateLiving extends Event {
}

