package me.rich.module;

public enum Category {
	COMBAT, PLAYER, MOVEMENT, RENDER, MISC, HUD
	}
