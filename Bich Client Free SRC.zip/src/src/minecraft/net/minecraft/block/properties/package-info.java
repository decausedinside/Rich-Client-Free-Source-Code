@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block.properties;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;